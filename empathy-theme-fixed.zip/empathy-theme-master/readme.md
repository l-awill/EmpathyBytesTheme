# Empathy Theme by Jaewon Drake built on Plate

Empathy Theme is built for the Empathy Bytes VIP team at Georgia Institute of Technology in Atlanta, GA. The theme is designed to be used to upload podcasts/videos and other types of media files in conjunction with plug-ins. 

To view info about our VIP team and the Web Design Track, visit our official Wiki page: https://vip.gatech.edu/wiki/index.php/Everyday_Georgia#Web_Design_Track

The theme is built on the Plate theme (https://github.com/joshuaiz/plate) designed by "Joshua Michaels for studio.bio: https://studio.bio/ with help from Jon Iler".
