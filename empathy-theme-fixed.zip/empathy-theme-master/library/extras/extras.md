# Plate Theme Extras

#### Just a few bits in here that we often use at studio.bio. If you don't need any of this, delete or just leave it alone. 

We've placed it in the `/extras` folder because they are...wait for it...*extras* that you may or may not need or want. 

## Icons
Retina credit card icons in .svg format. We use these to replace the default Gravity Forms icons which are still not retina (*le sigh*).

How to use with Gravity Forms (for example with the Stripe CC field block):

.gform_card_icon_amex {
	background-image: url(../images/icons/amex.svg) !important;
	background-position: 0 0 !important;
	background-size: 36px 32px;
}

Repeat for each card. Maybe one day, Gravity Forms will get their act together. Sheeeeesh.
