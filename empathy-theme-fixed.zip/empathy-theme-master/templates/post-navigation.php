<div class="post-navigation">

	<?php plate_page_navi( $wp_query ); ?>

</div>