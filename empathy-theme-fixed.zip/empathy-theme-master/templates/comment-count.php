<p class="footer-comment-count">
	<?php comments_number( __( '<span>No</span> Comments', 'platetheme' ), __( '<span>One</span> Comment', 'platetheme' ), __( '<span>%</span> Comments', 'platetheme' ) );?>
</p>